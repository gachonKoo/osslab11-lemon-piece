import math

def cube(side):
    return side ** 3

def sphere(radius):
    return (4/3) * math.pi * radius ** 3

def cylinder(radius, height):
    return math.pi * radius ** 2 * height
