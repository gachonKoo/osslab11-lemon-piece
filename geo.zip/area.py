import math

def circle(radius):
    return math.pi * radius ** 2

def rectangle(width, height):
    return width * height

def triangle(base, height):
    return 0.5 * base * height
